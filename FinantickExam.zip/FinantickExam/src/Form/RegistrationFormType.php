<?php

namespace App\Form;

use App\Entity\Users;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\IsTrue;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;

class RegistrationFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('username')
            ->add('plainPassword', PasswordType::class, [
                // instead of being set onto the object directly,
                // this is read and encoded in the controller
                'mapped' => false,
                'attr' => ['autocomplete' => 'new-password'],
                'constraints' => [
                    new NotBlank([
                        'message' => 'Please enter a password',
                    ]),
                    new Length([
                        'min' => 6,
                        'minMessage' => 'Your password should be at least {{ limit }} characters',
                        // max length allowed by Symfony for security reasons
                        'max' => 4096,
                    ]),
                    new \Symfony\Component\Validator\Constraints\Regex([
                        'pattern' => '/(?=.*[a-z])(?=.*[A-Z])/',
                        'message' => 'Please enter a password with at least one uppercase and one lowercase',
                        ])
                ],
            ])
            ->add('user_type', ChoiceType::class,
                [
                    'choices' => [
                        'Register as an User' => 'user',
                        'Register as an Agent' => 'agent',
                    ],
                    'mapped' => false,
                    'expanded' => true,
                    'choice_attr' => function ($choice, $key, $value) {
                        return ['v-model' => 'account_type'];
            }
                ]
            )
            ->add('agent_role', ChoiceType::class,
                [
                    'choices' => [
                        'Admin' => 'admin',
                        'Rep' => 'rep',
                    ],
                    'mapped' => false
                ]
            )
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Users::class,
        ]);
    }
}
